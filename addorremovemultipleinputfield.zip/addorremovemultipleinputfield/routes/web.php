<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\ProductController;



Route::get('add-more', [ProductController::class, 'index']);
Route::post('add-more', [ProductController::class, 'store'])->name('add-more.store');;
