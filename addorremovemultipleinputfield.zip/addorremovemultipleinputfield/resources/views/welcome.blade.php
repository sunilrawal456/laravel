<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Form</title>
</head>
<body>
    <form action="" method="POST"  enctype="multipart/form-data">
        @csrf
        <input type="text" name="name">
        <input type="email" name="email">
        <input type="file" name="image" >
        <input type="submit"  value="submit">
    </form>

</body>
</html>