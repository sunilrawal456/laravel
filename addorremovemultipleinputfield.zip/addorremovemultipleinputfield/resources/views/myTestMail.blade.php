<!DOCTYPE html>

<html>

<head>

    <title>ItsolutionStuff.com</title>

</head>

<body>

    <h1>{{ $name }}</h1>
    <p>{{ $email }}</p>
    <p>Thank you</p>

</body>

</html>