<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', [HomeController::class, 'index'])->name('home.index');
Route::get('usershow/{id}', [HomeController::class, 'show'])->name('home.show');
Route::delete('deleteuser/{id}', [HomeController::class, 'destroy'])->name(name: 'home.delete');
Route::post('userstore', [HomeController::class, 'userstore'])->name(name: 'user.store');
Route::get('useredit/{id}', [HomeController::class, 'useredit'])->name(name: 'user.edit');
Route::post('userupdate/{id}', [HomeController::class, 'userupdate'])->name(name: 'user.update');