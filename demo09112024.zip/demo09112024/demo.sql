-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 01, 2025 at 06:24 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `abouts`
--

CREATE TABLE `abouts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `abouts`
--

INSERT INTO `abouts` (`id`, `created_at`, `updated_at`, `description`) VALUES
(1, NULL, NULL, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@mail.com', '$2y$12$yrYP0WGUuSUTS5HID/UJMOVyFhtupsCvd6pTtwXTC1luvW5KYyBBa', '2024-11-13 02:56:57', '2024-11-13 02:56:57');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `department_id` varchar(255) NOT NULL,
  `department_name` varchar(255) NOT NULL,
  `hod` varchar(255) NOT NULL,
  `started_date` date NOT NULL,
  `no_of_students` int(11) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `department_id`, `department_name`, `hod`, `started_date`, `no_of_students`, `description`, `created_at`, `updated_at`) VALUES
(2, '1219', 'suscipit', 'EA', '1993-04-11', 88, 'Cum tempora voluptatibus vel unde iste corrupti cumque. Mollitia maiores ratione id quo voluptatem voluptate est. In nostrum dolorem consectetur debitis.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(3, '1243', 'nihil', 'ET', '1999-05-01', 71, 'Incidunt quia quod possimus consequuntur sit vitae qui. Exercitationem nemo veniam quam quaerat laboriosam ut. Ut corporis accusantium et et sed sunt porro.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(4, '1289', 'accusantium', 'MINUS', '2003-07-25', 116, 'Vel cum mollitia et architecto officia. Doloremque aut repellendus sed nobis optio ut provident. Dolorem molestiae beatae quisquam aspernatur asperiores et. Inventore cumque ex qui quis.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(5, '1275', 'similique', 'VOLUPTATIBUS', '2014-04-22', 112, 'Ullam nisi voluptatem nulla est corrupti reiciendis rerum. Quis eos doloremque quaerat quo debitis corporis. Et molestiae quia est voluptatem qui.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(6, '1310', 'aut', 'EARUM', '1979-09-21', 91, 'Eos et nesciunt eius ipsam voluptatibus voluptas rerum odit. Est et quos nulla beatae id suscipit. Natus nobis maxime qui. Dolor alias et qui rem.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(7, '1266', 'repellat', 'IN', '2000-11-13', 110, 'Occaecati odit eveniet expedita molestiae libero qui et voluptatem. Officiis sint iure enim neque inventore. Minus distinctio minima aut saepe deserunt.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(8, '1325', 'ipsam', 'SINT', '2012-03-14', 68, 'Facilis eaque cumque omnis voluptates ad atque maiores. Et rerum qui repudiandae deserunt soluta facilis est. Corporis minus ipsam doloribus voluptatem.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(9, '1208', 'placeat', 'IURE', '2011-08-28', 58, 'Laboriosam dolor ut impedit autem maxime dolor. Asperiores cumque voluptatum sunt voluptatem corrupti voluptatem. Est pariatur asperiores eos ut sit.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(10, '1261', 'eius', 'RERUM', '1983-04-14', 82, 'Commodi quos impedit quod sit maxime. Delectus at culpa et voluptas ea optio. Doloribus soluta voluptatem vitae inventore est ut.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(11, '1290', 'soluta', 'ASPERIORES', '1998-08-26', 53, 'Reiciendis inventore consectetur voluptates harum aut. Velit nisi inventore mollitia tenetur.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(12, '1287', 'et', 'ODIO', '2019-02-09', 91, 'Et in voluptatibus quis harum et eligendi asperiores. Praesentium deserunt dolores dolor corporis. Praesentium aut possimus delectus maxime quo magni. Aut perspiciatis in sunt veniam tenetur eum cum.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(13, '1367', 'nihil', 'EARUM', '1970-12-04', 126, 'Occaecati eum in aut rerum sed qui excepturi. Qui dolorem cum voluptas. Id neque similique optio voluptas.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(14, '1260', 'nesciunt', 'VOLUPTAS', '1977-12-27', 132, 'Qui amet iusto nemo veritatis voluptates. Veniam ipsum nihil natus quo. Culpa blanditiis dolor nobis sunt qui.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(15, '1269', 'provident', 'QUI', '1973-05-03', 74, 'Dolores numquam hic rerum id totam dolorem et. Sunt dolor nihil totam dolor optio sed. Odio veritatis et quo et non. Et eveniet repudiandae ratione aut.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(16, '1380', 'autem', 'LIBERO', '2021-10-04', 101, 'Fugit aut veniam illum sit consequatur vitae. Omnis hic dolor repellat ipsa. Vel consequatur sed harum voluptas hic animi. Inventore alias facere unde est beatae.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(17, '1203', 'deserunt', 'QUAE', '1970-11-05', 83, 'Aspernatur quo facere aliquid adipisci quam. Sapiente nam officiis perspiciatis ut occaecati aut. Necessitatibus enim molestiae voluptate maiores quos similique est omnis.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(18, '1261', 'voluptatem', 'REPELLAT', '1991-12-21', 141, 'Reprehenderit ratione odio minus non et error quo. Ex architecto et sint non explicabo non eum. Nisi rerum repellendus ut magni. Vel velit non eius officiis assumenda repellendus.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(19, '1374', 'nihil', 'QUO', '2006-03-15', 63, 'Ut autem repellendus perspiciatis cum molestias dolorum rerum qui. Aut voluptates corrupti velit maiores unde fugit.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(20, '1326', 'sapiente', 'MODI', '2023-01-14', 114, 'In praesentium doloribus error quod. Maxime quisquam nemo aliquam quia. Et assumenda id animi incidunt voluptas accusamus. Autem ullam eveniet repellat et veritatis eaque dolorem.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(21, '1268', 'voluptatem', 'DELENITI', '1973-02-09', 82, 'Et mollitia voluptas consequatur sed qui suscipit quisquam. Omnis quisquam fuga nemo ut. Vero provident omnis fuga. Quis consequatur provident quibusdam velit qui dolorem.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(22, '1258', 'est', 'ESSE', '2013-10-12', 88, 'Odit nam aspernatur sit ea reiciendis voluptates quod. Eos et qui occaecati explicabo et pariatur non. Exercitationem est eos ab aut doloribus dolor consequatur quo.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(23, '1376', 'velit', 'MOLESTIAE', '1992-02-14', 54, 'Repellendus est velit aut animi autem repudiandae repudiandae. In temporibus veritatis nemo sapiente recusandae voluptate quis. Cupiditate nulla quisquam explicabo ducimus facilis.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(24, '1262', 'dolorem', 'CONSECTETUR', '2014-07-23', 99, 'Impedit praesentium ut eum commodi sit quod corrupti. Quas sit iste ut. Atque rerum tenetur inventore possimus maiores. Quibusdam in ipsum voluptate amet quod ex id. Culpa et atque est repellendus a.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(25, '1292', 'iusto', 'QUIA', '2006-05-25', 143, 'Architecto sed sapiente reiciendis alias voluptatem rerum aliquid. Nostrum unde voluptas iure ut earum. Vel in sit consequatur. Voluptatem et et eos officiis. Itaque impedit ipsa alias id aut.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(26, '1325', 'quae', 'ENIM', '1981-04-27', 123, 'Incidunt consequuntur voluptate quod hic. Et quisquam quo debitis neque id quos. Sunt et laboriosam accusamus rerum cupiditate.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(27, '1308', 'necessitatibus', 'ASPERNATUR', '2021-11-01', 73, 'Sint excepturi voluptatibus alias. Et ab et facilis iusto nemo voluptatibus.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(28, '1397', 'omnis', 'TENETUR', '2011-04-03', 137, 'Illo eius veniam sed ut quaerat nostrum. Dolore iste non autem ratione odit. Nobis dolorem aut et dolore nulla voluptate labore id.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(29, '1372', 'sed', 'VOLUPTATEM', '1990-09-29', 53, 'Enim molestiae consequuntur hic sint eos. Facere dolores et molestiae vel. Est est eum rerum suscipit. Tempora rem molestiae et placeat aut. Voluptas a id porro molestias sunt.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(30, '1319', 'tempore', 'ET', '1988-03-27', 101, 'Ut quam repellat ut est accusamus veniam. Iure numquam omnis amet et expedita ut ea. Cum laboriosam est aut sit quam quidem.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(31, '1308', 'eum', 'OPTIO', '1995-11-05', 71, 'Beatae nemo nulla aliquam repellendus omnis. Aut aut ut quia ut ut quisquam. Et optio aliquam ipsam qui assumenda sit. Autem sunt voluptatem vel ea.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(32, '1222', 'ratione', 'DOLOR', '1982-02-12', 69, 'Exercitationem dolores in ex in. Laboriosam aut rerum fugiat ea nihil quia corrupti. Nemo et sit nemo et.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(33, '1281', 'voluptas', 'NESCIUNT', '2020-04-14', 128, 'Eos beatae voluptate tempore sit. Nisi est sed enim id sint at. Modi sit fuga nulla. Minima officia nam unde aliquam aspernatur. Tempore earum est et in rerum debitis quia.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(34, '1223', 'natus', 'TEMPORE', '2009-07-01', 118, 'Ipsum ut repellendus culpa odio autem doloribus. Eum cumque expedita et. Enim asperiores et quasi hic animi veniam. Omnis sequi omnis voluptatum earum qui.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(35, '1359', 'voluptas', 'ATQUE', '1977-10-10', 105, 'Rerum qui magni enim culpa. Sed est sed et temporibus repudiandae.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(36, '1280', 'dolores', 'QUO', '1987-11-12', 58, 'Magnam dolores repellat est autem iusto accusantium aut. Corporis vero nostrum quia architecto aperiam commodi voluptas nihil. Vel velit eos hic sunt error sint. Ad nihil et et pariatur minima quasi.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(37, '1294', 'iure', 'CONSEQUUNTUR', '1977-08-17', 148, 'Ut et et repellat. Delectus sunt nihil nobis aspernatur aut earum. Et et ullam reprehenderit. Modi dolores sit neque architecto sit.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(38, '1330', 'id', 'RATIONE', '1978-05-15', 91, 'Totam aut magni consectetur quia. Corrupti iure eius itaque ut corrupti error consectetur voluptate.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(39, '1245', 'cupiditate', 'DOLORUM', '2012-09-01', 89, 'Rerum et ex at rerum numquam minus. Explicabo quas fuga dolor omnis. Quae rerum dolorem debitis saepe aut occaecati.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(40, '1348', 'ullam', 'QUIA', '2003-11-25', 78, 'Fugit odio odio at recusandae quidem blanditiis dolorem. Quaerat et cumque ut ea natus commodi. Rem necessitatibus velit ut dolorem a nobis dolores.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(41, '1234', 'rem', 'DOLOREMQUE', '1978-02-10', 143, 'Odit sequi vero iste veniam molestias voluptas. Corporis doloribus ducimus reprehenderit voluptas hic. Quia impedit repellendus eos quo sit facere repudiandae. Et rerum laborum dolore quod facilis.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(42, '1358', 'et', 'IPSUM', '1996-06-17', 92, 'Sequi necessitatibus temporibus rerum. Assumenda eum id optio tenetur. Aut voluptatem qui alias nam placeat aut.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(43, '1279', 'tempora', 'FACILIS', '1989-05-16', 72, 'Odit incidunt officia et animi voluptatibus dolorem a fugiat. Et dicta est quia iure perferendis qui tempore. Sit dolor earum quo. Rerum eum ratione quam ut ut illo.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(44, '1306', 'consequatur', 'AMET', '1992-12-04', 124, 'Esse porro vero error veritatis assumenda. Fugit ut eum non. Voluptatem quam nesciunt dolorem ut incidunt.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(45, '1371', 'non', 'MAIORES', '1970-01-05', 127, 'Soluta facere nihil sunt non accusantium. Rem alias et sit voluptas dolor et est. Aut dicta nam quam unde ullam.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(46, '1286', 'distinctio', 'NATUS', '2012-03-12', 59, 'Aut nihil vitae quam et voluptas. Consectetur quia voluptate asperiores in non officia voluptas. Qui ut incidunt dolores omnis omnis quis illum saepe. Et suscipit qui ad illo reprehenderit.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(47, '1271', 'et', 'NOSTRUM', '1983-05-23', 127, 'Veritatis laboriosam et tenetur. Eum earum inventore vel nobis.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(48, '1339', 'ut', 'AUT', '1985-02-13', 103, 'Qui quos voluptatem quis sed. Dolor enim non ea est reprehenderit eius. Unde reprehenderit cumque debitis ut id corrupti. Est sit magni laborum aliquid saepe.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(49, '1367', 'ducimus', 'NECESSITATIBUS', '1989-08-13', 107, 'Ducimus ipsum corporis nam maxime non magni cupiditate. Eveniet voluptatem numquam sunt a voluptates. A eum dolore sit quia possimus quis.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(50, '1326', 'et', 'NESCIUNT', '1990-11-19', 106, 'Est aut temporibus dignissimos suscipit impedit. Voluptatem est labore cupiditate. Eos sit debitis magni maiores. Tenetur omnis libero nostrum rerum. Enim aspernatur ipsa eaque.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(51, '1350', 'impedit', 'SIMILIQUE', '1987-01-23', 92, 'Omnis vel incidunt vero earum. Esse voluptates et quod nulla officiis. Ut voluptates tenetur voluptates quod quaerat aspernatur. Qui pariatur debitis inventore inventore.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(52, '1367', 'et', 'ET', '2022-11-26', 88, 'Error temporibus sit omnis harum aliquid adipisci nam aperiam. Culpa incidunt iusto consequatur voluptas voluptatem nihil. Rem quia excepturi mollitia veritatis doloribus.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(53, '1375', 'quae', 'DOLORUM', '1977-03-13', 146, 'Unde id possimus velit minima enim corrupti vero. Aperiam ipsum et necessitatibus itaque culpa earum. Id aspernatur libero rerum repellat ut aliquam ipsa.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(54, '1266', 'dolorem', 'EST', '2005-12-17', 63, 'Aliquam veritatis dolor temporibus ex. Minima explicabo earum quam commodi. Voluptatibus odit voluptatem impedit dicta reprehenderit quisquam minima distinctio.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(55, '1280', 'tempora', 'QUI', '1993-01-22', 127, 'Nisi qui unde ad iusto. Repellendus in ut iure. Harum doloribus odio quia ducimus. Tempora rem ad non perspiciatis similique animi. Itaque non aut nulla eum eum.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(56, '1365', 'dolores', 'TEMPORIBUS', '2011-01-01', 69, 'Quae itaque facere ut labore vero. Eos ut deleniti sit dicta eaque culpa. Beatae dicta laborum eum ut et maxime. Sint fugit numquam beatae architecto laudantium et.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(57, '1390', 'atque', 'VOLUPTATUM', '1976-06-10', 78, 'Ut aut nostrum odio vel quidem et consequatur aut. Necessitatibus aspernatur nihil animi consequatur sunt provident nostrum non. Molestiae sit est molestiae ut nemo.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(58, '1333', 'neque', 'ALIQUID', '1974-05-06', 55, 'Ut voluptas non expedita quis consequuntur quos id. Sed facilis voluptates vero aut. Exercitationem facere tempore nemo corporis et.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(59, '1391', 'fugiat', 'RECUSANDAE', '2014-01-04', 82, 'Facere aut rem eveniet vero itaque voluptatem repellendus. Assumenda nesciunt unde consequuntur minima et ut.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(60, '1273', 'quae', 'EST', '2018-08-03', 88, 'Est aliquam reprehenderit aperiam delectus nulla et. Dolorem quo inventore molestias. Officiis dolores nihil voluptatem odio maiores.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(61, '1219', 'vitae', 'QUIA', '1992-07-29', 77, 'Debitis mollitia facilis asperiores qui. Porro fugiat aliquam natus dolor ea.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(62, '1277', 'voluptatem', 'AUT', '2019-08-03', 113, 'Eos quae rerum temporibus sint tempora. Dignissimos voluptas dolores quae doloribus eligendi officia. Sint neque mollitia quos animi. Quia quo omnis nobis et doloribus.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(63, '1298', 'sed', 'SED', '1987-12-28', 88, 'Veniam ex ea voluptatem nobis sed nam vel. Iure ut sed qui earum aut recusandae odio. Deserunt odio debitis animi temporibus est occaecati quis.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(64, '1233', 'labore', 'EST', '2014-10-25', 76, 'Quas nihil rerum architecto accusamus a repellendus. In hic aliquid est in neque nostrum. Quia optio eum pariatur nihil nulla ut dolorem. Repellat porro rem voluptas et sint voluptas praesentium.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(65, '1306', 'quam', 'NULLA', '2016-02-11', 122, 'Ea iusto quasi neque tempore qui omnis. Tenetur velit autem delectus aut rerum molestias et. Esse commodi officiis quia accusantium.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(66, '1238', 'rerum', 'IN', '1970-06-18', 129, 'Quidem aliquid distinctio minima iusto facilis est ut. Repellendus quas voluptas esse et ex. Non cupiditate ut dolorum velit placeat voluptate esse. A nesciunt natus qui.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(67, '1219', 'harum', 'CORRUPTI', '1986-04-09', 52, 'Delectus perspiciatis voluptas sit qui labore vel. Officiis quis ut nisi quis est. Amet eaque eius aut libero enim dolor harum consequatur.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(68, '1213', 'sit', 'EST', '1980-06-26', 103, 'Voluptatem ad aut quia eos. Et neque qui et suscipit facere. Vel quibusdam magni sed qui eos. Eos repellat sint qui minus dolorem quas perferendis unde.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(69, '1393', 'minus', 'CONSEQUATUR', '1994-02-11', 78, 'Velit et ut odio quia incidunt dolor eaque. Fuga delectus cumque cum et quod est quasi. Laudantium non aut iure.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(70, '1374', 'quasi', 'QUI', '1999-06-25', 101, 'Autem voluptatum nostrum nulla commodi. Ut minus tempora pariatur voluptas dolor consectetur inventore. Harum ipsa nihil consequatur sit qui.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(71, '1310', 'rerum', 'TOTAM', '1977-07-08', 126, 'In iure dolorem harum quis. Animi assumenda officiis et libero nemo. Voluptates iusto quod sed rerum distinctio. Enim exercitationem recusandae excepturi.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(72, '1388', 'beatae', 'EUM', '1977-12-09', 143, 'Aut illo iure culpa dicta ratione iste. Et hic sint corrupti. Officia enim laudantium dolorum omnis eveniet. Aspernatur recusandae vel iure vitae fugiat ipsum est.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(73, '1365', 'veritatis', 'FUGA', '1983-05-26', 63, 'Deserunt maiores facere sunt itaque enim omnis. Aut quam inventore ut ut eligendi molestias. Dolore nemo dicta nesciunt et aperiam. Pariatur sed optio suscipit voluptas et fugit harum sapiente.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(74, '1223', 'laudantium', 'REPUDIANDAE', '1977-08-30', 57, 'Delectus voluptates qui eaque error tempora est quibusdam molestiae. Ut rerum est non illo dolore nisi vitae. Numquam quisquam cumque sed saepe voluptatem.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(75, '1393', 'qui', 'DOLOR', '1975-12-11', 64, 'Necessitatibus deleniti ut impedit exercitationem ad labore quis. Impedit eius similique expedita non. Totam nostrum quod sed assumenda architecto.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(76, '1241', 'est', 'APERIAM', '1987-10-13', 100, 'Sed ut iure sequi expedita repudiandae. Error optio at natus eum et consequuntur nisi. Quia aut vero pariatur quia. Quia sit odit earum dolores ab dolor voluptatibus. Sunt minus mollitia ab.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(77, '1331', 'eligendi', 'DICTA', '1988-06-27', 70, 'Est molestiae omnis magnam. Sint sed corrupti ea fugit ut saepe reiciendis voluptatem. Occaecati consequuntur et ut est.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(78, '1288', 'id', 'IPSA', '1972-02-12', 76, 'Id velit enim repudiandae rerum hic cum qui. Sit soluta voluptatem beatae dolorem pariatur aspernatur et. Ut consequatur qui ducimus sed.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(79, '1205', 'officiis', 'ODIO', '1970-01-10', 105, 'Et delectus quo id. Quaerat animi itaque voluptates perspiciatis quia. Ut unde velit qui quo.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(80, '1254', 'laboriosam', 'VELIT', '1980-11-28', 80, 'Minus tenetur odit facere. Et est dolorem natus eius nihil perspiciatis. Architecto nisi molestiae quasi consequatur et neque atque.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(81, '1223', 'nihil', 'QUOD', '2023-08-23', 77, 'Aut voluptas sit odit ipsum est facere ut. Id ullam ratione iure magnam.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(82, '1200', 'earum', 'MAXIME', '1983-01-14', 120, 'Nesciunt omnis repellendus sed quae et labore quibusdam et. Quis ut dolor voluptates ut saepe.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(83, '1316', 'distinctio', 'LABORE', '2005-11-15', 93, 'Autem et recusandae qui amet. Ullam odio eveniet quasi. Quia cum enim placeat dolores. Omnis eius qui amet nihil magni non ab.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(84, '1246', 'sit', 'DOLOREM', '1983-05-15', 69, 'Perferendis sit quod necessitatibus sint eum quis. Illum ea ut exercitationem consequatur debitis consequatur autem.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(85, '1240', 'ullam', 'QUIDEM', '2021-06-11', 56, 'Id earum sit est ut id id dolore. Nulla quas sit explicabo possimus voluptatem quia. Et omnis eos ut et dolorum ex possimus. Est fuga et voluptates ea ex. Et ab voluptas reiciendis ut ratione animi.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(86, '1216', 'eum', 'OMNIS', '1993-03-27', 115, 'Enim inventore sapiente numquam asperiores voluptate earum et. Corporis laboriosam eligendi ea exercitationem. Enim animi voluptatibus ut soluta. Voluptas quidem consequuntur tempore asperiores.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(87, '1224', 'sunt', 'AUT', '2005-07-04', 50, 'Cupiditate pariatur reiciendis rerum voluptas nobis magni. Maxime sit natus natus. Nemo quis ducimus libero labore sunt rerum eos.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(88, '1322', 'corporis', 'ID', '1986-10-14', 102, 'Sed et expedita eius animi officia. Voluptatem ea excepturi error pariatur expedita. Inventore id doloribus impedit veniam id odio sed officiis. Ducimus itaque aliquid vel et omnis pariatur.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(89, '1389', 'sunt', 'SAEPE', '1981-05-12', 54, 'Nihil rerum fuga praesentium est. Aut voluptates reprehenderit et culpa. Occaecati in perferendis et sunt autem quas. Fugit qui alias eos temporibus molestiae.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(90, '1215', 'quod', 'CUM', '1998-05-22', 126, 'Voluptates magnam aut tenetur veritatis necessitatibus quisquam sit. Hic quis excepturi architecto consequuntur eius pariatur. Quia est consequatur ea quia ipsum.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(91, '1363', 'quia', 'TENETUR', '2006-04-11', 56, 'Ducimus provident ut cumque mollitia totam repudiandae. Nisi consectetur doloribus sit culpa necessitatibus error placeat. Earum et quae placeat a. Consectetur laboriosam ut facilis aut.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(92, '1371', 'iure', 'ET', '2014-04-09', 71, 'Ex adipisci animi sit quam praesentium earum libero. Unde odit et quod ut. Optio qui doloremque reiciendis possimus. Vero incidunt saepe veritatis numquam quaerat vero.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(93, '1208', 'a', 'NON', '1992-06-07', 112, 'Mollitia ut itaque sint. Facere quod blanditiis repudiandae error optio praesentium. Itaque eos reiciendis ipsam eos enim laudantium ipsum sint. Nam aut quos ipsa enim autem et.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(94, '1283', 'accusamus', 'OCCAECATI', '2013-09-18', 67, 'Suscipit omnis aut maiores quis ut suscipit. Rerum sit sit dolorem aliquid provident. Est tempore neque id nobis aut aut minus.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(95, '1385', 'dicta', 'CORPORIS', '2001-08-26', 100, 'Sunt tempora aut praesentium in iusto est nemo nihil. Rem cumque iusto facilis itaque. Nihil amet a et eveniet.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(96, '1230', 'debitis', 'TEMPORA', '1979-09-03', 121, 'Quos molestias ex a perspiciatis. Dolor molestiae est totam aut consequatur autem.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(97, '1257', 'aliquid', 'MAGNAM', '2015-03-15', 54, 'Illum dolores perferendis recusandae optio in dolorem. Autem esse voluptatem ratione doloribus nemo.', '2024-11-13 02:58:00', '2024-11-13 02:58:00'),
(98, '1219', 'architecto', 'DEBITIS', '1999-01-02', 83, 'Quo voluptatem quia in beatae aut necessitatibus. Non in ad omnis cum quasi corrupti. Tempore ipsam architecto doloribus.', '2024-11-13 02:58:00', '2024-11-13 02:58:00');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fasters`
--

CREATE TABLE `fasters` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `fasters`
--

INSERT INTO `fasters` (`id`, `created_at`, `updated_at`, `description`) VALUES
(1, NULL, NULL, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.');

-- --------------------------------------------------------

--
-- Table structure for table `headers`
--

CREATE TABLE `headers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `headers`
--

INSERT INTO `headers` (`id`, `created_at`, `updated_at`, `description`) VALUES
(1, NULL, NULL, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `imageable_id` int(11) NOT NULL,
  `imageable_type` varchar(255) NOT NULL,
  `imageable_path` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `knows`
--

CREATE TABLE `knows` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `knows`
--

INSERT INTO `knows` (`id`, `created_at`, `updated_at`, `description`) VALUES
(1, NULL, NULL, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2024_10_26_071137_create_departments_table', 1),
(6, '2024_10_28_115755_create_images_table', 1),
(7, '2024_11_06_121125_create_admins_table', 1),
(8, '2024_11_12_092917_create_abouts_table', 1),
(9, '2024_11_12_092935_create_knows_table', 1),
(10, '2024_11_12_092952_create_notes_table', 1),
(11, '2024_11_12_093015_create_headers_table', 1),
(12, '2024_11_12_093116_create_fasters_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notes`
--

INSERT INTO `notes` (`id`, `created_at`, `updated_at`, `description`) VALUES
(1, NULL, NULL, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'User', 'user@mail.com', '2024-11-13 02:56:39', '$2y$12$ZUgNDVuGQ/LIkc7bEd82sedXbkhov7J2/LLcNgqVfF59tBdqVFhcq', 'kKHkK8FZGA', '2024-11-13 02:56:40', '2024-11-13 02:56:40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abouts`
--
ALTER TABLE `abouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `fasters`
--
ALTER TABLE `fasters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `headers`
--
ALTER TABLE `headers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `knows`
--
ALTER TABLE `knows`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `abouts`
--
ALTER TABLE `abouts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fasters`
--
ALTER TABLE `fasters`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `headers`
--
ALTER TABLE `headers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `knows`
--
ALTER TABLE `knows`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
