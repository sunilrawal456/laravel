@extends('admin.layout.app')
@section('content')
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-12 d-flex no-block align-items-center">
                <h4 class="page-title"><a href="{{ route('add.department') }}" class="btn btn-outline-primary btn-sm">Add+</a>
                </h4>
                <h4 class="page-title" style="margin-left:10px;"><a href="{{ route('department.pdf') }}"
                        class="btn btn-outline-secondary btn-sm">PDF</a></h4>
                <h4 class="page-title" style="margin-left:10px;"><a href="{{ route('export') }}"
                        class="btn btn-outline-warning btn-sm">Export</a></h4>
                <div class="ms-auto text-end">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('list.department') }}">Department</a></li>
                            <li class="breadcrumb-item active" aria-current="page">
                                Department List
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-12">

                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="zero_config1" class="table table-striped table-bordered">
                                <thead>
                                    <tr>

                                        <th>Sno</th>
                                        <th>Department Name</th>
                                        <th>HOD</th>
                                        <th>Start date</th>
                                        <th>No of students</th>
                                        <th>Image</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End PAge Content -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Right sidebar -->
        <!-- ============================================================== -->
        <!-- .right-sidebar -->
        <!-- ============================================================== -->
        <!-- End Right sidebar -->
        <!-- ============================================================== -->
    </div>
@endsection
@section('script')
    <script type="text/javascript">
        $('body').on('click', '.deleteProduct', function() {
            var table = $('#zero_config1').DataTable();
            var id = $(this).data("id");
            const url = 'delete-department/' + id;

            Swal.fire({
                title: 'Are you sure to delete this record?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {

                    $.ajax({
                        type: "DELETE",
                        url: url,
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(data) {
                            table.draw();
                        },
                        error: function(xhr, status, error) {
                            console.log('Error:', error);
                            Swal.fire(
                                'Error!', 'There was an issue deleting the item.', 'error'
                            );
                        }
                    });
                }
            });
        });

        $(function() {
            var table = $('#zero_config1').DataTable({

                // {{-- "pageLength": 500
                //, "lengthMenu": [500, 1000, 1500, 2000, 2500] --}}
                processing: true,
                serverSide: true,
                ajax: "{{ route('list.department') }}",
                order: [
                    [0, 'desc']
                ],

                columns: [

                    {
                        data: null,
                        name: 'serial_no',
                        searchable: false,
                        orderable: false,
                        render: function(data, type, row, meta) {
                            return meta.settings._iDisplayStart + meta.row + 1;

                        }
                    },


                    {
                        data: 'department_name',
                        name: 'department_name'
                    },

                    {
                        data: 'hod',
                        name: 'hod'
                    }, {
                        data: 'started_date',
                        name: 'started_date'
                    }, {
                        data: 'no_of_students',
                        name: 'no_of_students'
                    },

                    {
                        data: 'image',
                        name: 'image',
                        orderable: false,
                        searchable: false
                    },

                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    },
                ]
            });
        });
    </script>
@endsection
