<?php

namespace App\Http\Controllers\admin;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\User;
use App\Models\Image;
use App\Models\Admin;
use App\Models\Department;
use Barryvdh\DomPDF\Facade\Pdf;
use App\Exports\DepartmentExport;
use Maatwebsite\Excel\Facades\Excel;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\File;


class AdminController extends Controller
{
    public function index()
    {
        return view('admin.auth.login');
    }


    public function logincheck(Request $request)
    {
        $request->validate([
            'email' => 'required',
            'password' => 'required'
        ]);


        if (Auth::guard('admin')->attempt(['email' => $request->email, 'password' => $request->password])) {
            return redirect()->route('dashboard');
        } else {
            return redirect()->route('logout');
        }
    }


    public function logout()
    {

        Auth::guard('admin')->logout();
        return view('admin.auth.login');
    }


    public function dashboard()
    {
        return view('admin.dashboard');
    }



}