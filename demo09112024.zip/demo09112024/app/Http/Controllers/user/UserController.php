<?php

namespace App\Http\Controllers\user;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function index()
    {
        return view('user.auth.login');
    }


    public function userlogincheck(Request $request)
    {
        $request->validate([
            'email' => 'required',
            'password' => 'required'
        ]);


        if (Auth::guard('web')->attempt(['email' => $request->email, 'password' => $request->password])) {
            return redirect()->route('userdashboard');
        } else {
            return redirect()->route('logout');
        }
    }


    public function userlogout()
    {
        Auth::guard('web')->logout();
        return view('user.auth.login');
    }


    public function userdashboard()
    {
        return view('user.dashboard');
    }
}