<?php
namespace App\Exports;
use App\Models\Department;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithChunkReading;


class DepartmentExport implements FromCollection, WithHeadings, WithChunkReading, WithEvents, ShouldAutoSize
{

    public function collection()
    {
        return Department::all('id', 'department_id', 'department_name', 'hod', 'started_date', 'no_of_students');
    }

    public function headings(): array
    {
        return [
            'ID',
            'DEPARTMENT ID',
            'DEPARTMENT NAME',
            'HOD',
            'STARTED DATE',
            'NO OF STUDENTS'

        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {

                $event->sheet->getDelegate()->getStyle('A1:F1')
                    ->getFont()
                    ->setBold(true);


                $event->sheet->getDelegate()->getStyle('A1:F' . $event->sheet->getHighestRow())
                    ->getAlignment()
                    ->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER)
                    ->setVertical(\PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER)
                    ->setWrapText(true);
            },
        ];
    }


    public function chunkSize(): int
    {
        return 1000;
    }

}