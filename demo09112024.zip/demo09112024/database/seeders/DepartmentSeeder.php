<?php

namespace Database\Seeders;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Department;
use Faker\Factory as Faker;


class DepartmentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $faker = Faker::create();

        for ($i = 0; $i < 100; $i++) {
            Department::create([
                'department_id' => $faker->numberBetween(1200, 1400),
                'department_name' => $faker->word,
                'hod' => strtoupper($faker->word),
                'no_of_students' => $faker->numberBetween(50, 150),
                'started_date' => \Carbon\Carbon::parse($faker->date)->format('Y-m-d'),
                'description' => $faker->text
            ]);
        }
    }
}